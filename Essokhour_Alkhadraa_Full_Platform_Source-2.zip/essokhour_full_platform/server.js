require("dotenv").config();
const express = require("express");
const session = require("express-session");
const SQLiteStore = require("connect-sqlite3")(session);
const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");

const app = express();
const PORT = process.env.PORT || 3000;
const DB_PATH = process.env.DB_PATH || path.join(__dirname, "data", "app.sqlite");
const UPLOAD_DIR = process.env.UPLOAD_DIR || path.join(__dirname, "uploads");
fs.mkdirSync(path.dirname(DB_PATH), {recursive:true});
fs.mkdirSync(UPLOAD_DIR, {recursive:true});
if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32) {
  console.warn("WARNING: Set SESSION_SECRET to a long random secret before production.");
}
const db = new Database(DB_PATH);
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('admin','staff')),
 active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS requests (
 id INTEGER PRIMARY KEY AUTOINCREMENT, ref TEXT UNIQUE NOT NULL,
 service TEXT NOT NULL, name TEXT NOT NULL, phone TEXT NOT NULL, email TEXT,
 details TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'received',
 staff_note TEXT DEFAULT '', missing_docs TEXT DEFAULT '', quote TEXT DEFAULT '',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS events (
 id INTEGER PRIMARY KEY AUTOINCREMENT, request_id INTEGER NOT NULL,
 status TEXT NOT NULL, message TEXT DEFAULT '', actor TEXT DEFAULT 'system',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(request_id) REFERENCES requests(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS documents (
 id INTEGER PRIMARY KEY AUTOINCREMENT, request_id INTEGER NOT NULL,
 original_name TEXT NOT NULL, stored_name TEXT NOT NULL, mime_type TEXT NOT NULL,
 size INTEGER NOT NULL, uploaded_by TEXT NOT NULL DEFAULT 'customer',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(request_id) REFERENCES requests(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS activity_log (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, username TEXT NOT NULL,
 action TEXT NOT NULL, request_ref TEXT DEFAULT '', details TEXT DEFAULT '',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);
const statusNames = {
 received:"تم استلام الطلب", review:"قيد المراجعة", missing:"وثائق ناقصة",
 processing:"قيد المعالجة", completed:"مكتمل", cancelled:"ملغى"
};
const insertEvent = db.prepare("INSERT INTO events(request_id,status,message,actor) VALUES(?,?,?,?)");
const log = db.prepare("INSERT INTO activity_log(user_id,username,action,request_ref,details) VALUES(?,?,?,?,?)");
function audit(req, action, ref="", details="") {
  if (req.session.user) log.run(req.session.user.id, req.session.user.username, action, ref, details);
}
function requireAuth(req,res,next){ if(!req.session.user) return res.redirect("/admin/login"); next(); }
function requireAdmin(req,res,next){ if(!req.session.user || req.session.user.role!=="admin") return res.status(403).send(page("غير مسموح","هذه الصفحة متاحة للمدير فقط.")); next(); }
function esc(v=""){return String(v).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function page(title, body, extra=""){return `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#087ed0"><title>${esc(title)} | الصخور الخضراء</title><link rel="stylesheet" href="/style.css"></head><body>${body}${extra}<script src="/app.js"></script></body></html>`;}
function shell(content, active=""){return `<header class="nav"><a class="brand" href="/"><span class="mark">✈</span><span><b>الصخور الخضراء للسياحة والأسفار</b><small>Essokhour Alkhadraa Travel</small></span></a><button class="hamb" onclick="document.querySelector('.links').classList.toggle('show')">☰</button><nav class="links"><a href="/#services">خدماتنا</a><a href="/#request">اطلب خدمة</a><a href="/track">متابعة طلبي</a><a href="/admin/login">دخول الموظفين</a></nav></header>${content}<footer class="footer">© ${new Date().getFullYear()} الصخور الخضراء للسياحة والأسفار · نسخة قابلة للتخصيص</footer><a class="wa" href="${esc(process.env.PUBLIC_WHATSAPP_URL || '#contact')}" aria-label="WhatsApp">☎</a>`;}
function newRef(service){
 const p={"تذكرة طيران":"TK","فندق":"HOTEL","عمرة":"OMRA","رحلة منظمة":"TRIP","Visa":"VISA","e-Visa":"EVISA","تأمين السفر":"INS"};
 return `${p[service]||"REQ"}-${new Date().getFullYear()}-${crypto.randomBytes(3).toString("hex").toUpperCase()}`;
}
const storage = multer.diskStorage({
 destination:(req,file,cb)=>cb(null,UPLOAD_DIR),
 filename:(req,file,cb)=>cb(null,crypto.randomUUID()+path.extname(file.originalname).toLowerCase())
});
const upload = multer({
 storage, limits:{fileSize:8*1024*1024,files:5},
 fileFilter:(req,file,cb)=>{
   const allowed=["application/pdf","image/jpeg","image/png"];
   if(!allowed.includes(file.mimetype)) return cb(new Error("يسمح فقط بملفات PDF وJPG وPNG."));
   cb(null,true);
 }
});
app.use(helmet({contentSecurityPolicy:false}));
app.use(express.urlencoded({extended:false,limit:"30kb"}));
app.use(express.json({limit:"30kb"}));
app.use(session({
 secret:process.env.SESSION_SECRET || "development-only-change-this-session-secret",
 resave:false,saveUninitialized:false,
 store:new SQLiteStore({db:"sessions.sqlite",dir:path.join(__dirname,"data")}),
 cookie:{httpOnly:true,sameSite:"lax",secure:process.env.NODE_ENV==="production",maxAge:8*60*60*1000}
}));
app.use(express.static(path.join(__dirname,"public")));
app.use("/admin/static",express.static(path.join(__dirname,"public")));

app.get("/",(req,res)=>{
 const body=`<main><section class="hero"><div class="heroText"><span class="tag">رحلتك تبدأ من هنا</span><h1>سافر بثقة،<br><em>ونحن نتكفّل بالباقي</em></h1><p>العمرة، الرحلات، تذاكر الطيران، الفنادق والتأشيرات — خدماتك السياحية في مكان واحد.</p><div class="actions"><a class="btn orange" href="#request">اطلب خدمتك الآن</a><a class="btn white" href="/track">تابع طلبي</a></div><div class="chips">✓ متابعة واضحة　 ✓ خدمات متنوعة　 ✓ تواصل مباشر</div></div><div class="heroArt"><div class="sun"></div><div class="plane">✈</div><div class="heroBadge">ESSOKHOUR<br>ALKHADRAA TRAVEL</div></div></section>
 <section id="services" class="section"><div class="heading"><span class="tag">خدماتنا</span><h2>كل ما تحتاجه لرحلتك</h2><p>اختر الخدمة وأرسل طلبك بسهولة.</p></div><div class="services">${[["🕋","عمرة"],["🌍","رحلة منظمة"],["✈️","تذكرة طيران"],["🏨","فندق"],["🛂","Visa"],["🛡️","تأمين السفر"],["📄","e-Visa"]].map(([i,s])=>`<a class="service" href="#request" data-service="${esc(s)}"><span>${i}</span><b>${esc(s)}</b><small>تقديم طلب أونلاين</small></a>`).join("")}</div></section>
 <section class="section offers"><div class="heading"><span class="tag">وجهتك القادمة</span><h2>عروض الوكالة</h2><p>تُضاف العروض والتواريخ والأسعار من لوحة التحكم بعد تجهيز إدارة العروض.</p></div><div class="notice">✦　العروض والأسعار الفعلية تُؤكد مباشرة من الوكالة قبل الحجز.</div></section>
 <section id="request" class="section formSection"><div class="heading"><span class="tag">ابدأ طلبك</span><h2>ما الخدمة التي تحتاجها؟</h2><p>املأ النموذج وستحصل على رقم مرجعي لمتابعة طلبك.</p></div><form class="card formGrid" action="/requests" method="post"><label>نوع الخدمة *<select name="service" id="service" required><option value="">اختر الخدمة</option>${["عمرة","رحلة منظمة","تذكرة طيران","فندق","Visa","e-Visa","تأمين السفر"].map(s=>`<option>${s}</option>`).join("")}</select></label><label>الاسم الكامل *<input name="name" required maxlength="120"></label><label>رقم الهاتف *<input name="phone" required type="tel" maxlength="40"></label><label>البريد الإلكتروني<input name="email" type="email" maxlength="160"></label><label class="wide">تفاصيل الطلب *<textarea name="details" rows="4" required maxlength="4000" placeholder="الوجهة، التواريخ، عدد المسافرين وأي تفاصيل مهمة..."></textarea></label><label class="check wide"><input type="checkbox" required> أوافق على استخدام بياناتي للتواصل معي بشأن هذا الطلب.</label><button class="btn orange wide">إرسال الطلب</button><small class="wide privacy">لا ترسل وثائق جواز السفر عبر هذا النموذج. ارفع الوثائق فقط من صفحة المتابعة الآمنة بعد إنشاء الطلب.</small></form></section>
 <section class="trackStrip"><div><span class="tag">متابعة الملف</span><h2>كل تحديث في مكان واحد</h2><p>استخدم رقم الطلب لمعرفة الحالة ورفع الوثائق المطلوبة عند الحاجة.</p></div><a class="btn white" href="/track">متابعة طلبي ←</a></section>
 <section id="contact" class="section contact"><h2>هل تحتاج إلى مساعدة؟</h2><p>أضف أرقام الهاتف وWhatsApp الرسمية للوكالة قبل النشر.</p><a class="btn orange" href="mailto:${esc(process.env.PUBLIC_CONTACT_EMAIL||'')}" ${process.env.PUBLIC_CONTACT_EMAIL?'':'hidden'}>راسلنا</a></section></main>`;
 res.send(page("الرئيسية",shell(body)));
});
app.post("/requests",rateLimit({windowMs:15*60*1000,max:20,standardHeaders:true,legacyHeaders:false}), (req,res)=>{
 const {service,name,phone,email,details}=req.body;
 if(!service||!name?.trim()||!phone?.trim()||!details?.trim()) return res.status(400).send(page("بيانات ناقصة",shell(`<main class="message"><h1>يرجى إكمال الحقول المطلوبة</h1><a class="btn orange" href="/">العودة</a></main>`)));
 if(!["عمرة","رحلة منظمة","تذكرة طيران","فندق","Visa","e-Visa","تأمين السفر"].includes(service)) return res.status(400).send("خدمة غير صالحة");
 const ref=newRef(service);
 const info=db.prepare("INSERT INTO requests(ref,service,name,phone,email,details) VALUES(?,?,?,?,?,?)").run(ref,service,name.trim(),phone.trim(),(email||"").trim(),details.trim());
 insertEvent.run(info.lastInsertRowid,"received","تم استلام الطلب","system");
 res.send(page("تم استلام الطلب",shell(`<main class="message"><div class="successIcon">✓</div><h1>تم استلام طلبك بنجاح</h1><p>احتفظ برقم الطلب التالي لمتابعة الملف.</p><div class="ref">${esc(ref)}</div><p>سيتمكن فريق الوكالة من مراجعة طلبك من لوحة التحكم.</p><a class="btn orange" href="/track?ref=${encodeURIComponent(ref)}">متابعة الطلب</a><a class="textLink" href="/">العودة للرئيسية</a></main>`)));
});
app.get("/track",(req,res)=>{
 const ref=String(req.query.ref||"").trim();
 let result="";
 if(ref){
   const r=db.prepare("SELECT * FROM requests WHERE ref=?").get(ref);
   if(r){
     const events=db.prepare("SELECT * FROM events WHERE request_id=? ORDER BY id ASC").all(r.id);
     const docs=db.prepare("SELECT id,original_name,created_at FROM documents WHERE request_id=? ORDER BY id DESC").all(r.id);
     result=`<section class="card trackCard"><div class="ref">${esc(r.ref)}</div><h2>${esc(r.service)} · ${esc(r.name)}</h2><p class="status status-${esc(r.status)}">${esc(statusNames[r.status]||r.status)}</p><div class="timeline">${events.map((e,i)=>`<div class="step ${i===events.length-1?'current':'done'}"><span></span><div><b>${esc(statusNames[e.status]||e.status)}</b>${e.message?`<small>${esc(e.message)}</small>`:""}<small>${esc(e.created_at)}</small></div></div>`).join("")}</div>${r.missing_docs?`<div class="missing"><b>الوثائق المطلوبة:</b><p>${esc(r.missing_docs)}</p><form action="/track/${encodeURIComponent(r.ref)}/documents" method="post" enctype="multipart/form-data"><label>رفع الوثائق (PDF/JPG/PNG، حتى 8MB لكل ملف)<input type="file" name="documents" multiple required accept=".pdf,.jpg,.jpeg,.png"></label><button class="btn orange">رفع الوثائق</button></form></div>`:""}${r.staff_note?`<p><b>رسالة الوكالة:</b> ${esc(r.staff_note)}</p>`:""}${r.quote?`<div class="notice"><b>عرض السعر:</b> ${esc(r.quote)}</div>`:""}<h3>الوثائق المرفوعة</h3><ul>${docs.map(d=>`<li>${esc(d.original_name)} — ${esc(d.created_at)}</li>`).join("")||"<li>لا توجد وثائق مرفوعة.</li>"}</ul></section>`;
   } else result=`<div class="alert">لم نعثر على طلب بهذا الرقم. تحقق من الرقم أو تواصل مع الوكالة.</div>`;
 }
 const body=`<main class="section pageNarrow"><div class="heading"><span class="tag">متابعة الملف</span><h1>متابعة طلبي</h1><p>أدخل رقم الطلب المرجعي لمعرفة آخر تحديث.</p></div><form class="card lookup" method="get" action="/track"><label>رقم الطلب<input name="ref" value="${esc(ref)}" required placeholder="VISA-2026-ABC123"></label><button class="btn orange">بحث عن الطلب</button></form>${result}</main>`;
 res.send(page("متابعة طلبي",shell(body)));
});
app.post("/track/:ref/documents", (req,res,next)=>{
 upload.array("documents",5)(req,res,err=>{if(err)return res.status(400).send(page("تعذر رفع الملفات",shell(`<main class="message"><h1>${esc(err.message)}</h1><a href="/track?ref=${encodeURIComponent(req.params.ref)}">عودة</a></main>`)));next();});
},(req,res)=>{
 const r=db.prepare("SELECT * FROM requests WHERE ref=?").get(req.params.ref);
 if(!r){(req.files||[]).forEach(f=>fs.unlinkSync(f.path));return res.status(404).send("الطلب غير موجود");}
 if(r.status!=="missing"){(req.files||[]).forEach(f=>fs.unlinkSync(f.path));return res.status(400).send("الوكالة لم تطلب وثائق إضافية لهذا الملف.");}
 const add=db.prepare("INSERT INTO documents(request_id,original_name,stored_name,mime_type,size,uploaded_by) VALUES(?,?,?,?,?,?)");
 (req.files||[]).forEach(f=>add.run(r.id,path.basename(f.originalname),f.filename,f.mimetype,f.size,"customer"));
 db.prepare("UPDATE requests SET updated_at=CURRENT_TIMESTAMP WHERE id=?").run(r.id);
 insertEvent.run(r.id,"review","تم رفع وثائق جديدة، بانتظار مراجعة الوكالة","customer");
 res.redirect("/track?ref="+encodeURIComponent(r.ref));
});
app.get("/admin/login",(req,res)=>{
 const body=`<main class="loginWrap"><form class="card login" method="post" action="/admin/login"><span class="tag">مساحة الموظفين</span><h1>تسجيل الدخول</h1><label>اسم المستخدم<input name="username" required autocomplete="username"></label><label>كلمة المرور<input type="password" name="password" required autocomplete="current-password"></label><button class="btn orange">دخول</button><p class="privacy">حسابات الموظفين تُنشأ من المدير بعد إعداد الحساب الأول.</p></form></main>`;
 res.send(page("دخول الموظفين",body));
});
app.post("/admin/login",rateLimit({windowMs:15*60*1000,max:10}),async(req,res)=>{
 const user=db.prepare("SELECT * FROM users WHERE username=? AND active=1").get(String(req.body.username||"").trim());
 if(!user||!await bcrypt.compare(String(req.body.password||""),user.password_hash)) return res.status(401).send(page("تعذر الدخول",`<main class="message"><h1>بيانات الدخول غير صحيحة</h1><a href="/admin/login">حاول مرة أخرى</a></main>`));
 req.session.regenerate(err=>{if(err)return res.status(500).send("خطأ في الجلسة");req.session.user={id:user.id,username:user.username,role:user.role};log.run(user.id,user.username,"login","","تسجيل الدخول");res.redirect("/admin");});
});
app.post("/admin/logout",requireAuth,(req,res)=>{audit(req,"logout");req.session.destroy(()=>res.redirect("/admin/login"));});
app.get("/admin",requireAuth,(req,res)=>{
 const q=String(req.query.q||"").trim(), status=String(req.query.status||"");
 let sql="SELECT * FROM requests WHERE 1=1",args=[];
 if(q){sql+=" AND (name LIKE ? OR phone LIKE ? OR ref LIKE ?)";args.push(`%${q}%`,`%${q}%`,`%${q}%`);}
 if(status && statusNames[status]){sql+=" AND status=?";args.push(status);}
 sql+=" ORDER BY created_at DESC LIMIT 300";
 const rows=db.prepare(sql).all(...args);
 const count=db.prepare("SELECT COUNT(*) c FROM requests").get().c;
 const body=`<main class="adminPage"><div class="adminHead"><div><span class="tag">لوحة الوكالة</span><h1>مرحبًا، ${esc(req.session.user.username)}</h1><p>عدد الطلبات المسجلة: <b>${count}</b></p></div><form method="post" action="/admin/logout"><button class="btn white">تسجيل الخروج</button></form></div><div class="stats">${Object.entries(statusNames).map(([s,n])=>`<div class="stat"><small>${esc(n)}</small><b>${db.prepare("SELECT COUNT(*) c FROM requests WHERE status=?").get(s).c}</b></div>`).join("")}</div><form class="filters" method="get"><input name="q" value="${esc(q)}" placeholder="ابحث بالاسم أو الهاتف أو رقم الطلب"><select name="status"><option value="">كل الحالات</option>${Object.entries(statusNames).map(([s,n])=>`<option value="${s}" ${status===s?'selected':''}>${n}</option>`).join("")}</select><button class="btn orange">تصفية</button></form><div class="tableWrap"><table><thead><tr><th>رقم الطلب</th><th>الزبون</th><th>الخدمة</th><th>الهاتف</th><th>الحالة</th><th>تاريخ الطلب</th></tr></thead><tbody>${rows.map(r=>`<tr><td><a class="refLink" href="/admin/requests/${r.id}">${esc(r.ref)}</a></td><td>${esc(r.name)}</td><td>${esc(r.service)}</td><td>${esc(r.phone)}</td><td><span class="status status-${esc(r.status)}">${esc(statusNames[r.status])}</span></td><td>${esc(r.created_at)}</td></tr>`).join("")||`<tr><td colspan="6">لا توجد طلبات مطابقة.</td></tr>`}</tbody></table></div>${req.session.user.role==="admin"?`<section class="card adminCreate"><h2>إنشاء حساب موظف</h2><form action="/admin/users" method="post" class="inlineForm"><input name="username" required minlength="3" placeholder="اسم المستخدم"><input name="password" type="password" required minlength="12" placeholder="كلمة مرور قوية (12 حرفًا على الأقل)"><select name="role"><option value="staff">Staff</option><option value="admin">Admin</option></select><button class="btn orange">إنشاء الحساب</button></form></section><section class="card adminCreate"><h2>آخر سجل النشاط</h2><div class="tableWrap"><table><thead><tr><th>المستخدم</th><th>العملية</th><th>رقم الطلب</th><th>التفاصيل</th><th>التاريخ</th></tr></thead><tbody>${db.prepare("SELECT * FROM activity_log ORDER BY id DESC LIMIT 30").all().map(a=>`<tr><td>${esc(a.username)}</td><td>${esc(a.action)}</td><td>${esc(a.request_ref)}</td><td>${esc(a.details)}</td><td>${esc(a.created_at)}</td></tr>`).join("")||"<tr><td colspan=5>لا توجد نشاطات بعد.</td></tr>"}</tbody></table></div></section>`:""}</main>`;
 res.send(page("لوحة التحكم",shell(body)));
});
app.post("/admin/users",requireAuth,requireAdmin,async(req,res)=>{
 const username=String(req.body.username||"").trim(), password=String(req.body.password||""), role=req.body.role==="admin"?"admin":"staff";
 if(!/^[a-zA-Z0-9_.-]{3,50}$/.test(username)||password.length<12)return res.status(400).send("اسم المستخدم يجب أن يكون 3 أحرف على الأقل وكلمة المرور 12 حرفًا على الأقل.");
 try{db.prepare("INSERT INTO users(username,password_hash,role) VALUES(?,?,?)").run(username,await bcrypt.hash(password,12),role);audit(req,"create_user","",username+":"+role);res.redirect("/admin");}catch(e){res.status(400).send("تعذر إنشاء الحساب. قد يكون اسم المستخدم مستخدمًا.");}
});
app.get("/admin/requests/:id",requireAuth,(req,res)=>{
 const r=db.prepare("SELECT * FROM requests WHERE id=?").get(Number(req.params.id));if(!r)return res.status(404).send("الطلب غير موجود");
 const docs=db.prepare("SELECT * FROM documents WHERE request_id=? ORDER BY id DESC").all(r.id);
 const events=db.prepare("SELECT * FROM events WHERE request_id=? ORDER BY id DESC").all(r.id);
 const body=`<main class="adminPage"><a class="textLink" href="/admin">← العودة للطلبات</a><div class="detailHead"><div><span class="tag">ملف الزبون</span><h1>${esc(r.ref)}</h1><p>${esc(r.name)} · ${esc(r.service)}</p></div><span class="status status-${esc(r.status)}">${esc(statusNames[r.status])}</span></div><div class="detailGrid"><section class="card"><h2>معلومات الطلب</h2><p><b>الهاتف:</b> ${esc(r.phone)}</p><p><b>البريد:</b> ${esc(r.email)}</p><p><b>التفاصيل:</b><br>${esc(r.details)}</p><p><b>تاريخ الإنشاء:</b> ${esc(r.created_at)}</p><h3>الوثائق</h3><ul>${docs.map(d=>`<li><a href="/admin/documents/${d.id}">${esc(d.original_name)}</a> · ${esc(d.uploaded_by)}</li>`).join("")||"<li>لا توجد وثائق.</li>"}</ul><h3>سجل المراحل</h3><ul>${events.map(e=>`<li>${esc(statusNames[e.status]||e.status)} — ${esc(e.message)} (${esc(e.created_at)})</li>`).join("")}</ul></section><form class="card updateForm" method="post" action="/admin/requests/${r.id}"><h2>تحديث الملف</h2><label>الحالة<select name="status">${Object.entries(statusNames).map(([s,n])=>`<option value="${s}" ${r.status===s?'selected':''}>${n}</option>`).join("")}</select></label><label>الوثائق الناقصة<textarea name="missing_docs" rows="3" placeholder="مثال: نسخة جواز السفر">${esc(r.missing_docs)}</textarea></label><label>ملاحظة للزبون<textarea name="staff_note" rows="4">${esc(r.staff_note)}</textarea></label><label>عرض السعر<textarea name="quote" rows="3">${esc(r.quote)}</textarea></label><button class="btn orange">حفظ التحديث</button></form></div></main>`;
 res.send(page("تفاصيل الطلب",shell(body)));
});
app.post("/admin/requests/:id",requireAuth,(req,res)=>{
 const r=db.prepare("SELECT * FROM requests WHERE id=?").get(Number(req.params.id));if(!r)return res.status(404).send("الطلب غير موجود");
 const status=Object.hasOwn(statusNames,req.body.status)?req.body.status:r.status;
 const missing=String(req.body.missing_docs||"").slice(0,3000),note=String(req.body.staff_note||"").slice(0,3000),quote=String(req.body.quote||"").slice(0,2000);
 db.prepare("UPDATE requests SET status=?,missing_docs=?,staff_note=?,quote=?,updated_at=CURRENT_TIMESTAMP WHERE id=?").run(status,missing,note,quote,r.id);
 if(status!==r.status||missing!==r.missing_docs||note!==r.staff_note||quote!==r.quote){
   const message=status==="missing"?`وثائق مطلوبة: ${missing}`:note||"تم تحديث ملفك";
   insertEvent.run(r.id,status,message,req.session.user.username);
   audit(req,"update_request",r.ref,`status=${status}`);
 }
 res.redirect(`/admin/requests/${r.id}`);
});
app.get("/admin/documents/:id",requireAuth,(req,res)=>{
 const d=db.prepare("SELECT * FROM documents WHERE id=?").get(Number(req.params.id));if(!d)return res.status(404).send("الوثيقة غير موجودة");
 const file=path.join(UPLOAD_DIR,path.basename(d.stored_name));if(!fs.existsSync(file))return res.status(404).send("الملف غير موجود");
 audit(req,"download_document",String(d.request_id),d.original_name);
 res.download(file,d.original_name);
});
app.get("/health",(req,res)=>res.json({ok:true,service:"essokhour-travel"}));
app.use((err,req,res,next)=>{console.error(err);res.status(500).send(page("حدث خطأ",shell(`<main class="message"><h1>حدث خطأ غير متوقع</h1><p>حاول مرة أخرى أو تواصل مع مسؤول النظام.</p><a href="/">الرئيسية</a></main>`)));});
app.listen(PORT,()=>console.log(`Essokhour Travel platform running on port ${PORT}`));
