require("dotenv").config();
const Database=require("better-sqlite3");
const bcrypt=require("bcryptjs");
const path=require("path");
const dbPath=process.env.DB_PATH||path.join(__dirname,"data","app.sqlite");
const db=new Database(dbPath);
db.exec(`CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('admin','staff')), active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`);
(async()=>{
 const username=process.argv[2];
 const password=process.env.ADMIN_PASSWORD;
 if(!username||!password||password.length<12){console.error("Usage: ADMIN_PASSWORD='strong-password-12+' npm run create-admin -- username");process.exit(1);}
 try{db.prepare("INSERT INTO users(username,password_hash,role) VALUES(?,?,?)").run(username,await bcrypt.hash(password,12),"admin");console.log("Admin created:",username);}catch(e){console.error("Could not create admin; username may already exist.",e.message);process.exit(1);}
 db.close();
})();
